# ============================================================
# Personal Budget Tracker - Flask Application
# ============================================================
# This is the main backend file. It handles all routes,
# database operations, and user sessions.
# ============================================================

from flask import Flask, render_template, request, redirect, url_for, session, flash
from pymongo import MongoClient
from werkzeug.security import generate_password_hash, check_password_hash
from bson.objectid import ObjectId
from datetime import datetime
import os

# ---- App Setup ----
app = Flask(__name__)
app.secret_key = "budget_tracker_secret_key_2024"  # Used to sign session cookies

# ---- MongoDB Connection ----
# Make sure MongoDB is running locally on port 27017
client = MongoClient("mongodb://localhost:27017/")
db = client["budget_tracker_db"]  # Database name

# Collections (like tables in SQL)
users_col = db["users"]
income_col = db["income"]
expense_col = db["expense"]


# ============================================================
# HELPER FUNCTION
# ============================================================

def get_current_user():
    """Returns the logged-in user's data from the database."""
    if "user_id" in session:
        return users_col.find_one({"_id": ObjectId(session["user_id"])})
    return None


# ============================================================
# AUTHENTICATION ROUTES
# ============================================================

@app.route("/")
def index():
    """Home page - redirect to dashboard if logged in, else show landing page."""
    if "user_id" in session:
        return redirect(url_for("dashboard"))
    return render_template("index.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    """Handle user registration."""
    if request.method == "POST":
        name = request.form.get("name").strip()
        email = request.form.get("email").strip().lower()
        password = request.form.get("password")

        # Basic validation
        if not name or not email or not password:
            flash("All fields are required.", "danger")
            return redirect(url_for("register"))

        if len(password) < 6:
            flash("Password must be at least 6 characters.", "danger")
            return redirect(url_for("register"))

        # Check if email already exists
        existing_user = users_col.find_one({"email": email})
        if existing_user:
            flash("Email already registered. Please login.", "warning")
            return redirect(url_for("login"))

        # Hash the password before saving (never store plain text!)
        hashed_password = generate_password_hash(password)

        # Insert new user into database
        users_col.insert_one({
            "name": name,
            "email": email,
            "password": hashed_password,
            "created_at": datetime.now()
        })

        flash("Registration successful! Please login.", "success")
        return redirect(url_for("login"))

    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    """Handle user login."""
    if request.method == "POST":
        email = request.form.get("email").strip().lower()
        password = request.form.get("password")

        # Find user by email
        user = users_col.find_one({"email": email})

        # Check if user exists and password matches
        if user and check_password_hash(user["password"], password):
            session["user_id"] = str(user["_id"])  # Store user ID in session
            session["user_name"] = user["name"]
            flash(f"Welcome back, {user['name']}!", "success")
            return redirect(url_for("dashboard"))
        else:
            flash("Invalid email or password.", "danger")
            return redirect(url_for("login"))

    return render_template("login.html")


@app.route("/logout")
def logout():
    """Clear the session and log out the user."""
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("login"))


# ============================================================
# DASHBOARD ROUTE
# ============================================================

@app.route("/dashboard")
def dashboard():
    """Main dashboard showing summary of income, expenses, and balance."""
    if "user_id" not in session:
        flash("Please login to continue.", "warning")
        return redirect(url_for("login"))

    user_id = session["user_id"]

    # Fetch all income records for this user
    incomes = list(income_col.find({"user_id": user_id}).sort("date", -1))

    # Fetch all expense records for this user
    expenses = list(expense_col.find({"user_id": user_id}).sort("date", -1))

    # Calculate totals
    total_income = sum(item["amount"] for item in incomes)
    total_expense = sum(item["amount"] for item in expenses)
    balance = total_income - total_expense

    # ---- Monthly Report ----
    # Get current month and year
    now = datetime.now()
    current_month = now.month
    current_year = now.year

    # Filter income/expenses for current month
    monthly_income = sum(
        item["amount"] for item in incomes
        if item["date"].month == current_month and item["date"].year == current_year
    )
    monthly_expense = sum(
        item["amount"] for item in expenses
        if item["date"].month == current_month and item["date"].year == current_year
    )

    # Only show the 5 most recent records on dashboard
    recent_incomes = incomes[:5]
    recent_expenses = expenses[:5]

    # ---- Chart Data: Last 6 months income vs expense ----
    # Build a list of the last 6 months (oldest → newest)
    from collections import defaultdict
    import calendar

    chart_labels = []       # e.g. ["Dec 2024", "Jan 2025", ...]
    chart_income = []       # total income per month
    chart_expense = []      # total expense per month

    for i in range(5, -1, -1):  # 5 months ago → current month
        # Calculate which year/month we're looking at
        month_num = (current_month - i - 1) % 12 + 1
        year_num  = current_year - ((current_month - i - 1) // 12 + (1 if (current_month - i - 1) < 0 else 0))

        label = f"{calendar.month_abbr[month_num]} {year_num}"
        chart_labels.append(label)

        m_income = sum(
            item["amount"] for item in incomes
            if item["date"].month == month_num and item["date"].year == year_num
        )
        m_expense = sum(
            item["amount"] for item in expenses
            if item["date"].month == month_num and item["date"].year == year_num
        )
        chart_income.append(round(m_income, 2))
        chart_expense.append(round(m_expense, 2))

    # ---- Chart Data: Expense by Category (Doughnut) ----
    category_totals = defaultdict(float)
    for item in expenses:
        category_totals[item["category"]] += item["amount"]

    cat_labels  = list(category_totals.keys())
    cat_amounts = [round(v, 2) for v in category_totals.values()]

    return render_template("dashboard.html",
        total_income=total_income,
        total_expense=total_expense,
        balance=balance,
        recent_incomes=recent_incomes,
        recent_expenses=recent_expenses,
        monthly_income=monthly_income,
        monthly_expense=monthly_expense,
        current_month=now.strftime("%B %Y"),
        # Chart data (passed as Python lists → Jinja → JS)
        chart_labels=chart_labels,
        chart_income=chart_income,
        chart_expense=chart_expense,
        cat_labels=cat_labels,
        cat_amounts=cat_amounts,
    )


# ============================================================
# INCOME ROUTES
# ============================================================

@app.route("/income")
def view_income():
    """View all income records for the logged-in user."""
    if "user_id" not in session:
        return redirect(url_for("login"))

    incomes = list(income_col.find({"user_id": session["user_id"]}).sort("date", -1))
    total = sum(item["amount"] for item in incomes)

    return render_template("add_income.html", incomes=incomes, total=total)


@app.route("/income/add", methods=["POST"])
def add_income():
    """Add a new income record."""
    if "user_id" not in session:
        return redirect(url_for("login"))

    source = request.form.get("source").strip()
    amount = request.form.get("amount")
    date_str = request.form.get("date")

    # Validate inputs
    if not source or not amount or not date_str:
        flash("All fields are required.", "danger")
        return redirect(url_for("view_income"))

    try:
        amount = float(amount)
        if amount <= 0:
            raise ValueError
    except ValueError:
        flash("Please enter a valid positive amount.", "danger")
        return redirect(url_for("view_income"))

    # Convert date string to datetime object
    date_obj = datetime.strptime(date_str, "%Y-%m-%d")

    # Insert into database
    income_col.insert_one({
        "user_id": session["user_id"],
        "source": source,
        "amount": amount,
        "date": date_obj
    })

    flash("Income added successfully!", "success")
    return redirect(url_for("view_income"))


@app.route("/income/delete/<income_id>")
def delete_income(income_id):
    """Delete an income record by its ID."""
    if "user_id" not in session:
        return redirect(url_for("login"))

    # Only delete if it belongs to the current user (security check)
    income_col.delete_one({
        "_id": ObjectId(income_id),
        "user_id": session["user_id"]
    })

    flash("Income record deleted.", "info")
    return redirect(url_for("view_income"))


# ============================================================
# EXPENSE ROUTES
# ============================================================

@app.route("/expense")
def view_expense():
    """View all expense records for the logged-in user."""
    if "user_id" not in session:
        return redirect(url_for("login"))

    expenses = list(expense_col.find({"user_id": session["user_id"]}).sort("date", -1))
    total = sum(item["amount"] for item in expenses)

    return render_template("add_expense.html", expenses=expenses, total=total)


@app.route("/expense/add", methods=["POST"])
def add_expense():
    """Add a new expense record."""
    if "user_id" not in session:
        return redirect(url_for("login"))

    category = request.form.get("category")
    amount = request.form.get("amount")
    date_str = request.form.get("date")

    # Allowed categories
    allowed_categories = ["Food", "Travel", "Shopping", "Bills", "Other"]

    # Validate inputs
    if not category or category not in allowed_categories:
        flash("Please select a valid category.", "danger")
        return redirect(url_for("view_expense"))

    if not amount or not date_str:
        flash("All fields are required.", "danger")
        return redirect(url_for("view_expense"))

    try:
        amount = float(amount)
        if amount <= 0:
            raise ValueError
    except ValueError:
        flash("Please enter a valid positive amount.", "danger")
        return redirect(url_for("view_expense"))

    date_obj = datetime.strptime(date_str, "%Y-%m-%d")

    # Insert into database
    expense_col.insert_one({
        "user_id": session["user_id"],
        "category": category,
        "amount": amount,
        "date": date_obj
    })

    flash("Expense added successfully!", "success")
    return redirect(url_for("view_expense"))


@app.route("/expense/delete/<expense_id>")
def delete_expense(expense_id):
    """Delete an expense record by its ID."""
    if "user_id" not in session:
        return redirect(url_for("login"))

    expense_col.delete_one({
        "_id": ObjectId(expense_id),
        "user_id": session["user_id"]
    })

    flash("Expense record deleted.", "info")
    return redirect(url_for("view_expense"))


# ============================================================
# RUN THE APP
# ============================================================

if __name__ == "__main__":
    # debug=True shows detailed errors during development
    # Set debug=False in production
    app.run(debug=True, port=5000)
