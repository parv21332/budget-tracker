# 💰 Personal Budget Tracker

A beginner-friendly web application built with **Flask**, **MongoDB**, and **Bootstrap 5** for managing personal income and expenses.

---

## 📁 Project Structure

```
budget-tracker/
│
├── app.py                  ← Main Flask application (all routes + logic)
├── requirements.txt        ← Python dependencies
│
├── static/
│   ├── css/style.css       ← Custom styles (on top of Bootstrap)
│   └── js/script.js        ← Simple JavaScript enhancements
│
├── templates/
│   ├── index.html          ← Landing / Home page
│   ├── login.html          ← Login page
│   ├── register.html       ← Registration page
│   ├── dashboard.html      ← Main dashboard with summary
│   ├── add_income.html     ← Income management page
│   └── add_expense.html    ← Expense management page
│
└── README.md               ← This file
```

---

## ✅ Features

- **User Authentication** — Register, Login, Logout with secure password hashing
- **Dashboard** — See Total Income, Total Expenses, Remaining Balance at a glance
- **Income Management** — Add, view, and delete income records
- **Expense Management** — Add, view, and delete expense records (5 categories)
- **Monthly Report** — Current month's income and expense totals on the dashboard
- **Flash Messages** — User feedback for every action (add, delete, login, etc.)
- **Session Management** — Users stay logged in until they logout

---

## 🛠 Tech Stack

| Layer    | Technology           |
|----------|----------------------|
| Frontend | HTML, CSS, Bootstrap 5 |
| Backend  | Python Flask         |
| Database | MongoDB (via PyMongo)|
| Auth     | Werkzeug (password hashing) |

---

## ⚙️ Setup Instructions

### Step 1 — Install MongoDB
Download and install MongoDB Community Server from:
https://www.mongodb.com/try/download/community

Start MongoDB service:
- **Windows**: Run `mongod` in terminal, or start via Services
- **macOS**: `brew services start mongodb-community`
- **Linux**: `sudo systemctl start mongod`

### Step 2 — Clone / Download the Project
```bash
# If using git:
git clone <your-repo-url>
cd budget-tracker

# Or just download and extract the ZIP, then:
cd budget-tracker
```

### Step 3 — Create a Virtual Environment (Recommended)
```bash
# Create virtual environment
python -m venv venv

# Activate it:
# Windows:
venv\Scripts\activate
# macOS/Linux:
source venv/bin/activate
```

### Step 4 — Install Python Dependencies
```bash
pip install -r requirements.txt
```

### Step 5 — Run the Application
```bash
python app.py
```

You should see:
```
 * Running on http://127.0.0.1:5000
 * Debug mode: on
```

### Step 6 — Open in Browser
Visit: **http://localhost:5000**

---

## 🗄️ MongoDB Collections

The app automatically creates these collections in the `budget_tracker_db` database:

| Collection | Fields |
|------------|--------|
| `users`    | name, email, password (hashed), created_at |
| `income`   | user_id, source, amount, date |
| `expense`  | user_id, category, amount, date |

---

## 📌 Routes Summary

| Route | Method | Description |
|-------|--------|-------------|
| `/` | GET | Landing page |
| `/register` | GET, POST | User registration |
| `/login` | GET, POST | User login |
| `/logout` | GET | Clear session + logout |
| `/dashboard` | GET | Main dashboard |
| `/income` | GET | View all income |
| `/income/add` | POST | Add new income |
| `/income/delete/<id>` | GET | Delete income record |
| `/expense` | GET | View all expenses |
| `/expense/add` | POST | Add new expense |
| `/expense/delete/<id>` | GET | Delete expense record |

---

## 💡 Expense Categories

- 🍕 Food
- 🚌 Travel
- 🛍 Shopping
- 💡 Bills
- 📦 Other

---

## 🔐 Security Notes

- Passwords are **never stored as plain text** — Werkzeug's `generate_password_hash` is used
- Each user can only access their own data (user_id check on every DB query)
- Sessions are signed with a secret key

---

## 📝 Notes for Beginners

- `app.py` has comments explaining every section
- CSS variables in `style.css` make it easy to change colors
- `script.js` only adds small UX improvements (auto-date, confirm dialog, etc.)
- Flask's `flash()` is used to show success/error messages to users

---

## 🎓 Mini Project Info

- **Project Name**: Personal Budget Tracker
- **Course**: Web Development / Full Stack Mini Project
- **Stack**: Flask + MongoDB + Bootstrap 5
- **Difficulty**: Beginner-friendly
