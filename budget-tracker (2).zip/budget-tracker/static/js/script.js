// ============================================================
// Personal Budget Tracker - JavaScript
// ============================================================
// This file adds small interactive enhancements to the app.
// Flask/Jinja handles the main logic; JS just polishes the UX.
// ============================================================

// Run after the page has fully loaded
document.addEventListener("DOMContentLoaded", function () {

  // ---- 1. Auto-dismiss Flash Messages ----
  // Flash messages disappear automatically after 4 seconds
  const alerts = document.querySelectorAll(".alert");
  alerts.forEach(function (alert) {
    setTimeout(function () {
      // Fade out using Bootstrap's dismiss method
      const bsAlert = new bootstrap.Alert(alert);
      bsAlert.close();
    }, 4000); // 4000ms = 4 seconds
  });


  // ---- 2. Set Today's Date as Default in Date Fields ----
  // When the user opens a form, the date field auto-fills to today
  const dateInputs = document.querySelectorAll('input[type="date"]');
  const todayStr = new Date().toISOString().split("T")[0]; // Format: YYYY-MM-DD
  dateInputs.forEach(function (input) {
    if (!input.value) {
      input.value = todayStr;
    }
  });


  // ---- 3. Confirm Before Deleting ----
  // Shows a confirmation dialog when user clicks a delete button
  const deleteLinks = document.querySelectorAll(".btn-delete");
  deleteLinks.forEach(function (link) {
    link.addEventListener("click", function (e) {
      const confirmed = confirm("Are you sure you want to delete this record?");
      if (!confirmed) {
        e.preventDefault(); // Stop the navigation if user clicks Cancel
      }
    });
  });


  // ---- 4. Highlight Active Nav Link ----
  // Adds visual highlight to the currently active page in the navbar
  const currentPath = window.location.pathname;
  const navLinks = document.querySelectorAll(".nav-link");
  navLinks.forEach(function (link) {
    if (link.getAttribute("href") === currentPath) {
      link.classList.add("active");
    }
  });


  // ---- 5. Amount Field - Prevent Negative Numbers ----
  // The HTML `min="0.01"` helps, but this adds extra JS protection
  const amountFields = document.querySelectorAll('input[name="amount"]');
  amountFields.forEach(function (field) {
    field.addEventListener("input", function () {
      if (parseFloat(this.value) < 0) {
        this.value = "";
      }
    });
  });

  // ---- 6. Simple Number Formatting in Stat Cards ----
  // Formats numbers like 12500 → 12,500.00 for better readability
  const statValues = document.querySelectorAll(".stat-value, .report-value");
  statValues.forEach(function (el) {
    const raw = parseFloat(el.dataset.value);
    if (!isNaN(raw)) {
      el.textContent = "₹" + raw.toLocaleString("en-IN", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      });
    }
  });

});


// ============================================================
// 7. Download Table as HTML Report
// ============================================================
// This function reads the table on the page and generates a
// clean, styled HTML file the user can save and open in any
// browser — no server or extra library needed.
//
// Parameters:
//   tableId  - the id="" of the <table> element to download
//   filename - base name for the file (no extension needed)
// ============================================================

function downloadTableAsHTML(tableId, filename) {

  // Find the table element by its ID
  var table = document.getElementById(tableId);
  if (!table) {
    alert("Table not found!");
    return;
  }

  // Format today's date nicely for the report header
  var today = new Date().toLocaleDateString("en-IN", {
    day: "2-digit", month: "long", year: "numeric"
  });

  // Pick a friendly heading based on which table is being downloaded
  var reportTitle = (tableId === "income-table")
    ? "💵 Income Records Report"
    : "🧾 Expense Records Report";

  // ---- Build the table rows, skipping the "Action" (Delete) column ----
  var rows = table.querySelectorAll("tr");
  var tableHTML = "";

  rows.forEach(function (row, rowIndex) {
    var cells = row.querySelectorAll("th, td");
    var rowHTML = "<tr>";
    var colCount = cells.length;

    cells.forEach(function (cell, colIndex) {
      // Skip the last column (the Delete button column)
      if (colIndex === colCount - 1) return;

      var tag  = (rowIndex === 0) ? "th" : "td";
      var text = cell.innerText.trim();

      // Default cell styles
      var style = "";
      if (tag === "th") {
        style = 'style="background:#f4f6fb;color:#6b7280;font-size:0.75rem;text-transform:uppercase;letter-spacing:0.07em;padding:10px 14px;border-bottom:2px solid #e5e9f0;"';
      } else {
        style = 'style="padding:10px 14px;border-bottom:1px solid #f0f2f6;color:#1e2532;"';
      }

      // Colour the amount column green for income, red for expense
      if (text.startsWith("₹") && tag === "td") {
        var amtColor = (tableId === "income-table") ? "#0e9f6e" : "#e02424";
        style = 'style="padding:10px 14px;border-bottom:1px solid #f0f2f6;color:' + amtColor + ';font-family:monospace;font-weight:500;"';
      }

      rowHTML += "<" + tag + " " + style + ">" + text + "</" + tag + ">";
    });

    rowHTML += "</tr>";
    tableHTML += rowHTML;
  });

  // ---- Compose the full standalone HTML document ----
  var htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>${filename.replace(/_/g, " ")} — Budget Tracker</title>
  <style>
    body { font-family:'Segoe UI',Arial,sans-serif; background:#f4f6fb; color:#1e2532; margin:0; padding:2rem; }
    .report-header { background:#fff; border-radius:14px; border:1px solid #e5e9f0; padding:1.5rem 2rem; margin-bottom:1.5rem; box-shadow:0 2px 12px rgba(30,37,50,.07); }
    .report-header h1 { margin:0 0 .25rem; font-size:1.5rem; }
    .report-header p  { margin:0; color:#6b7280; font-size:.88rem; }
    .report-badge { display:inline-block; background:#dbeafe; color:#1e40af; border-radius:6px; padding:.2em .65em; font-size:.78rem; font-weight:600; margin-top:.5rem; }
    .table-wrap { background:#fff; border-radius:14px; border:1px solid #e5e9f0; overflow:hidden; box-shadow:0 2px 12px rgba(30,37,50,.07); }
    table { width:100%; border-collapse:collapse; font-size:.92rem; }
    tfoot td { padding:10px 14px; font-weight:700; background:#f8fafd; border-top:2px solid #e5e9f0; }
    .footer { text-align:center; margin-top:2rem; color:#9ca3af; font-size:.8rem; }
  </style>
</head>
<body>
  <div class="report-header">
    <h1>${reportTitle}</h1>
    <p>Generated on ${today} &nbsp;|&nbsp; Personal Budget Tracker</p>
    <span class="report-badge">📄 HTML Report</span>
  </div>
  <div class="table-wrap">
    <table>${tableHTML}</table>
  </div>
  <div class="footer">Personal Budget Tracker &mdash; Mini Project &copy; 2024</div>
</body>
</html>`;

  // ---- Trigger the browser file download ----
  // Create a Blob (binary large object) containing the HTML text,
  // attach it to a temporary invisible <a> link, click it, then clean up.
  var blob = new Blob([htmlContent], { type: "text/html;charset=utf-8;" });
  var url  = URL.createObjectURL(blob);

  var link      = document.createElement("a");
  link.href     = url;
  link.download = filename + "_" + new Date().toISOString().slice(0, 10) + ".html";
  document.body.appendChild(link);
  link.click();               // simulate the user clicking a download link
  document.body.removeChild(link);
  URL.revokeObjectURL(url);   // release the temporary object URL from memory
}
